import 'database_helper.dart';
import '../models/comment_model.dart';

class CommentService {
  final dbHelper = DatabaseHelper.instance;

  Future<List<CommentModel>> getComments(String postId) async {
    final db = await dbHelper.database;
    final List<Map<String, dynamic>> maps = await db.query(
      'comments',
      where: 'postId = ?',
      whereArgs: [postId],
      orderBy: 'createdAt DESC',
    );

    return List.generate(maps.length, (i) {
      return CommentModel.fromMap(maps[i]);
    });
  }

  Future<void> addComment(CommentModel comment) async {
    final db = await dbHelper.database;
    await db.insert('comments', {
      'id': comment.id,
      'postId': comment.postId,
      'userId': comment.userId,
      'userName': comment.userName,
      'content': comment.content,
      'createdAt': comment.createdAt.toIso8601String(),
    });
  }

  Future<void> deleteComment(String commentId) async {
    final db = await dbHelper.database;
    await db.delete(
      'comments',
      where: 'id = ?',
      whereArgs: [commentId],
    );
  }
}
