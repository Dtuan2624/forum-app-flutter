import 'dart:async';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'database_helper.dart';
import '../models/user.dart';

class AuthService {
  static const String _currentUserKey = 'forum_current_user';
  final dbHelper = DatabaseHelper.instance;

  UserModel? _currentUser;
  UserModel? get currentUser => _currentUser;

  final _controller = StreamController<UserModel?>.broadcast();
  Stream<UserModel?> get authStateChanges => _controller.stream;

  AuthService() {
    _init();
  }

  Future<void> _init() async {
    final prefs = await SharedPreferences.getInstance();
    final userJson = prefs.getString(_currentUserKey);
    if (userJson != null) {
      final map = jsonDecode(userJson);
      _currentUser = UserModel(
        id: map['id'],
        email: map['email'],
        name: map['name'],
        avatar: map['avatar'],
      );
      _controller.add(_currentUser);
    }
  }

  Future<void> login(String email, String password) async {
    final db = await dbHelper.database;
    final List<Map<String, dynamic>> maps = await db.query(
      'users',
      where: 'email = ? AND password = ?',
      whereArgs: [email, password],
    );

    if (maps.isEmpty) {
      throw Exception("Invalid credentials");
    }

    final userMap = maps.first;
    _currentUser = UserModel(
      id: userMap['id'],
      email: userMap['email'],
      name: userMap['name'],
      avatar: userMap['avatar'],
    );

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_currentUserKey, jsonEncode({
      'id': _currentUser!.id,
      'email': _currentUser!.email,
      'name': _currentUser!.name,
      'avatar': _currentUser!.avatar,
    }));

    _controller.add(_currentUser);
  }

  Future<void> register(String email, String password) async {
    final db = await dbHelper.database;
    final List<Map<String, dynamic>> existing = await db.query(
      'users',
      where: 'email = ?',
      whereArgs: [email],
    );

    if (existing.isNotEmpty) {
      throw Exception("User already exists");
    }

    final id = DateTime.now().millisecondsSinceEpoch.toString();
    final name = email.split('@')[0];
    
    await db.insert('users', {
      'id': id,
      'email': email,
      'password': password,
      'name': name,
      'avatar': '',
    });

    await login(email, password);
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_currentUserKey);
    _currentUser = null;
    _controller.add(null);
  }

  Future<void> updateProfile({required String uid, String? name, String? avatar}) async {
    final db = await dbHelper.database;
    Map<String, dynamic> updateData = {};
    if (name != null) updateData['name'] = name;
    if (avatar != null) updateData['avatar'] = avatar;

    if (updateData.isNotEmpty) {
      await db.update(
        'users',
        updateData,
        where: 'id = ?',
        whereArgs: [uid],
      );

      _currentUser = _currentUser?.copyWith(name: name, avatar: avatar);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_currentUserKey, jsonEncode({
        'id': _currentUser!.id,
        'email': _currentUser!.email,
        'name': _currentUser!.name,
        'avatar': _currentUser!.avatar,
      }));
      _controller.add(_currentUser);
    }
  }
}
