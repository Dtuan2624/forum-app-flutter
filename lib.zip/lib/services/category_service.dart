import 'database_helper.dart';
import '../models/category_model.dart';

class CategoryService {
  final dbHelper = DatabaseHelper.instance;

  Future<List<CategoryModel>> getCategories() async {
    final db = await dbHelper.database;
    final List<Map<String, dynamic>> maps = await db.query('categories');

    return List.generate(maps.length, (i) {
      return CategoryModel(
        id: maps[i]['id'],
        name: maps[i]['name'],
      );
    });
  }

  Future<void> createCategory(String name) async {
    final db = await dbHelper.database;
    await db.insert('categories', {
      'id': DateTime.now().millisecondsSinceEpoch.toString(),
      'name': name,
    });
  }

  Future<void> updateCategory(String id, String name) async {
    final db = await dbHelper.database;
    await db.update(
      'categories',
      {'name': name},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> deleteCategory(String id) async {
    final db = await dbHelper.database;
    await db.delete(
      'categories',
      where: 'id = ?',
      whereArgs: [id],
    );
  }
}
