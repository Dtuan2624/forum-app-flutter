import 'database_helper.dart';
import '../models/post_model.dart';
import 'dart:io';
import 'upload_service.dart';

class PostService {
  final dbHelper = DatabaseHelper.instance;
  final _uploadService = UploadService();

  Future<List<PostModel>> fetchPosts({String? categoryId}) async {
    final db = await dbHelper.database;
    
    List<Map<String, dynamic>> maps;
    if (categoryId != null) {
      maps = await db.query(
        'posts',
        where: 'categoryId = ?',
        whereArgs: [categoryId],
        orderBy: 'createdAt DESC',
      );
    } else {
      maps = await db.query('posts', orderBy: 'createdAt DESC');
    }

    return List.generate(maps.length, (i) {
      return PostModel(
        id: maps[i]['id'],
        title: maps[i]['title'],
        content: maps[i]['content'],
        categoryId: maps[i]['categoryId'],
        userId: maps[i]['userId'],
        imageUrl: maps[i]['imageUrl'],
        createdAt: DateTime.parse(maps[i]['createdAt']),
      );
    });
  }

  Future<void> createPost({
    required String title,
    required String content,
    required String categoryId,
    required String userId,
    dynamic image,
  }) async {
    final db = await dbHelper.database;
    
    String? imageUrl;
    if (image != null) {
      imageUrl = await _uploadService.upload(image);
    }

    await db.insert('posts', {
      'id': DateTime.now().millisecondsSinceEpoch.toString(),
      'title': title,
      'content': content,
      'categoryId': categoryId,
      'userId': userId,
      'imageUrl': imageUrl,
      'createdAt': DateTime.now().toIso8601String(),
    });
  }

  Future<void> updatePost({
    required String postId,
    required String title,
    required String content,
    String? categoryId,
    dynamic image,
    String? existingImageUrl,
  }) async {
    final db = await dbHelper.database;
    
    String? imageUrl = existingImageUrl;
    if (image != null) {
      imageUrl = await _uploadService.upload(image);
    }

    Map<String, dynamic> data = {
      'title': title,
      'content': content,
      'imageUrl': imageUrl,
    };
    if (categoryId != null) data['categoryId'] = categoryId;

    await db.update(
      'posts',
      data,
      where: 'id = ?',
      whereArgs: [postId],
    );
  }

  Future<void> deletePost(String postId) async {
    final db = await dbHelper.database;
    await db.delete(
      'posts',
      where: 'id = ?',
      whereArgs: [postId],
    );
  }
}
